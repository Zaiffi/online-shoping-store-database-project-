<?php
session_start();

if (isset($_GET['id'])) {
    $productId = $_GET['id'];
    if (isset($_SESSION['cart'][$productId])) {
        unset($_SESSION['cart'][$productId]);
    }
    // Redirect to cart page after removing
    header('Location: ../frontend/cart.php');  // Apne cart page ka sahi path yahan daalein
    exit();
} else {
    // Agar id nahi di gayi toh bhi cart page pe redirect kar dein
    header('Location: ../frontend/cart.php');
    exit();
}
?>
