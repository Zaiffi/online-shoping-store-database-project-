<?php

include('../connection.php');

$id = isset($_GET['id']) ? $_GET['id'] : '';

if ($id) {
    $data = "SELECT * FROM productproducts WHERE id = $id";
    $sql = mysqli_query($connection, $data);

    if ($sql) {
        $result = $sql->fetch_assoc();
    } else {
        echo "Error: " . mysqli_error($connection);
        $result = [];
    }
} else {
    $result = [];
}

?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
        integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>PHP</title>
</head>

<body>
    <div class="container mt-5">


        <div class="card">
            <div class="card-header">
                Add new product
                <a href="list.php" class="btn btn-primary float-right"> Products List</a>
            </div>
            <div class="card-body">


                <form action="insert.php" method="post" enctype="multipart/form-data">
                    <div class="row">
                        <!-- Hidden input for user ID -->
                        <input type="hidden" class="form-control" name="id"
                            value="<?php echo isset($result['id']) ? $result['id'] : ''; ?>">

                        <div class="col-md-6 form-group">
                            <label for="">Brand Name</label>
                            <input type="text" class="form-control" required name="brandname"
                                value="<?php echo isset($result['brandname']) ? $result['brandname'] : ''; ?>">
                        </div>

                        <div class="col-md-6 form-group">
                            <label for="">Cloth Name</label>
                            <input type="text" class="form-control" required name="clothname"
                                value="<?php echo isset($result['clothname']) ? $result['clothname'] : ''; ?>">
                        </div>

                        <div class="col-md-6 form-group">
                            <label for="">price</label>
                            <input type="text" class="form-control" required name="price"
                                value="<?php echo isset($result['price']) ? $result['price'] : ''; ?>">
                        </div>
                        <div class="col-md-6 form-group">
                            <label for="">Icon</label>
                            <input type="text" class="form-control" required name="icon"
                                value="<?php echo isset($result['icon']) ? $result['icon'] : ''; ?>">
                        </div>
                        <div class="col-md-6 form-group">
                            <label for="">Cart Icon</label>
                            <input type="text" class="form-control" required name="carticon"
                                value="<?php echo isset($result['carticon']) ? $result['carticon'] : ''; ?>">
                        </div>

                        <div class="col-md-6 form-group">
                            <label for="">Image</label>
                            <input type="file" class="form-control" name="image">
                        </div>

                        <div class="col-md-12 form-group mt-4">
                            <button class="btn btn-primary float-right" type="submit" name="submit">Submit</button>
                        </div>
                    </div>
                </form>

            </div>
        </div>

    </div>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct"
        crossorigin="anonymous"></script>

</body>

</html>