<?php

include('../connection.php');

if (isset($_POST['submit'])) {
    $id = isset($_POST['id']) ? $_POST['id'] : null;
    $brandname = $_POST['brandname'];
    $clothname = $_POST['clothname'];
    $price = $_POST['price'];
    $icon = $_POST['icon'];
    $carticon = $_POST['carticon'];
    $image = $_FILES["image"]["name"];
    $image_name = $_FILES["image"]["tmp_name"];
    $image_location = "Uploadimage/" . $image;

    // echo $brandname, $clothname, $price, $icon;
    // die();

    if (!empty($image_name)) {
        move_uploaded_file($image_name, $image_location);
    }

    if ($id) {
        // Update existing user
        if (!empty($image_name)) {
            $data_update = "UPDATE productproducts SET brandname = '$brandname', clothname = '$clothname', price = '$price', icon = '$icon', carticon = '$carticon', image = '$image' WHERE id = $id";
        } else {
            $data_update = "UPDATE productproducts SET brandname = '$brandname', clothname = '$clothname', price = '$price', icon = '$icon', carticon = '$carticon'  WHERE id = $id";
        }
        $query = mysqli_query($connection, $data_update);
    } else {
        // Insert new user
        $data_insert = "INSERT INTO productproducts (brandname, clothname, price, icon, carticon, image) VALUES ('$brandname', '$clothname', '$price', '$icon', '$carticon', '$image')";
        $query = mysqli_query($connection, $data_insert);
    }

    if ($query) {
        header('Location: list.php');
    } else {
        echo "Error: " . mysqli_error($connection);
    }
}

?>