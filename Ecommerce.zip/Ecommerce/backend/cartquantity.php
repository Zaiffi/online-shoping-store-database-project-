<?php
session_start();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include('../backend/connection.php');

    $product_id = intval($_POST['product_id']);
    $quantity = max(1, intval($_POST['quantity']));

    // Update session cart quantity
    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id] = $quantity;
    }

    // Get product price
    $result = $connection->query("SELECT price FROM indexproducts WHERE id = $product_id");

    if ($row = $result->fetch_assoc()) {
        $price = (int)$row['price'];
        $subtotal = $price * $quantity;

        // Calculate total for entire cart
        $total = 0;
        if (!empty($_SESSION['cart'])) {
            // Get all product IDs in cart
            $ids = implode(',', array_keys($_SESSION['cart']));
            $products_result = $connection->query("SELECT id, price FROM indexproducts WHERE id IN ($ids)");

            while ($prod = $products_result->fetch_assoc()) {
                $id = $prod['id'];
                $p = (int)$prod['price'];
                $q = $_SESSION['cart'][$id];
                $total += $p * $q;
            }
        }

        // Add shipping and tax (example: $2 shipping + $1 tax)
        $totalWithExtras = $total + 3;

        echo json_encode([
            'success' => true,
            'product_id' => $product_id,
            'subtotal' => $subtotal,
            'cartTotal' => $totalWithExtras
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Product not found']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
}
?>