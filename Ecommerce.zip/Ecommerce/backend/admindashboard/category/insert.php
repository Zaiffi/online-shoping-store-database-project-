<?php

include('../../connection.php');

if (isset($_POST['submit'])) {
    $id = isset($_POST['id']) ? $_POST['id'] : null;
    $categoryname = $_POST['categoryname'];
    $categorystatus = $_POST['categorystatus'];

    if ($id) {
        // Update existing category
        $data_update = "UPDATE categories SET categoryname = '$categoryname', categorystatus = '$categorystatus' WHERE id = $id";
        $query = mysqli_query($connection, $data_update);
    } else {
        // Insert new category
        $data_insert = "INSERT INTO categories (categoryname, categorystatus) VALUES ('$categoryname', '$categorystatus')";
        $query = mysqli_query($connection, $data_insert);
    }

    if ($query) {
        header('Location: list.php');
    } else {
        echo "Error: " . mysqli_error($connection);
    }
}
?>