<?php

$hostname = "localhost";
$username = "root";
$password = "";
$database = "ecommerce";

$connection = new mysqli($hostname,$username,$password, $database);

if(!$connection){
    echo "database is created successfully";
}
?>