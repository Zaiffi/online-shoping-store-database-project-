<?php
session_start();
include('../backend/connection.php');

$cartItems = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$products = [];

if (!empty($cartItems)) {
    $ids = implode(',', array_keys($cartItems));
    $result = $connection->query("SELECT * FROM indexproducts WHERE id IN ($ids)");

    while ($row = $result->fetch_assoc()) {
        $products[$row['id']] = $row;
    }
}

$orderSummary = [];
$total = 0;

foreach ($cartItems as $product_id => $qty) {
    if (!isset($products[$product_id])) continue;
    $price = (int)$products[$product_id]['price'];
    $subtotal = $price * (int)$qty;
    $total += $subtotal;

    $orderSummary[] = [
        'name' => $products[$product_id]['clothname'],
        'quantity' => $qty,
        'price' => $price,
        'subtotal' => $subtotal
    ];
}

// Save order summary to session for confirmation page
$_SESSION['order_summary'] = [
    'items' => $orderSummary,
    'total' => $total,
];

// Redirect to confirmation page
header('Location: confirmation.php');
exit();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        crossorigin="anonymous" />
    <link rel="stylesheet" href="https://unpkg.com/flickity@2/dist/flickity.min.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <title>Shope. | Cart | checkout</title>
</head>

<body>
    <!------------- NAV BAR -------------->

    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container">
            <a class="navbar-brand pt-3 pb-3" href="index.html">
                Shope.
            </a>
            <button class="navbar-toggler " type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fas fa-outdent"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link " href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " href="products.php">Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="blog.php">Blog</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="cart.php">
                            <i class="far fa-shopping-bag"></i>
                        </a>
                    </li>

                </ul>

            </div>
        </div>
    </nav>
    <!------------- NAV BAR END-------------->

    <!--------------- CHECKOUT SECTION --------------->

    <div class="checkout-section" style="margin-top: 120px;">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <h3>INFORMATION</h3>
                    <div class="card p-3 position-relative">
                        <!-- Edit Button -->
                        <a href="#" class="edit-btn">
                            <i class="fa fa-pencil"></i>
                        </a>

                        <div class="row pt-3">
                            <div class="info-box">
                                <div class="info-row">
                                    <div class="label"><b>Name:</b></div>
                                    <div>Huzaifa Khalil</div>
                                </div>
                                <div class="info-row pt-3">
                                    <div class="label"><b>Phone:</b></div>
                                    <div>03000000000</div>
                                </div>
                                <div class="info-row pt-3">
                                    <div class="label"><b>Email:</b></div>
                                    <div>huzaifa@gmail.com</div>
                                </div>
                                <div class="info-row pt-3">
                                    <div class="label"><b>Address:</b></div>
                                    <div>uenvihvbvnhke</div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <h3 class="pt-3">MY CART</h3>

                    <?php if (!$cartEmpty): ?>
                        <?php
                        foreach ($cartItems as $product_id => $qty):
                            if (!isset($products[$product_id])) {
                                echo "<p>Product ID $product_id not found</p>";
                                continue;
                            }

                            $product = $products[$product_id];

                            $quantity = (int)$qty;
                            $price = (int)$product['price'];
                            $subtotal = $price * $quantity;
                        ?>
                            <div class="card mt-2">
                                <div class="row left-sub-row p-3">
                                    <div class="col-md-3 pic">
                                        <img src="../backend/admindashboard/index/Uploadimage/<?php echo htmlspecialchars($product['image']); ?>"
                                            alt="<?php echo htmlspecialchars($product['clothname']); ?>" class="img-fluid" />
                                    </div>
                                    <div class="col-md-5 title">
                                        <h5><?php echo htmlspecialchars($product['clothname']); ?></h5>
                                        <p><b>Brand:</b> <?php echo htmlspecialchars($product['brandname']); ?></p>
                                        <p><span class="text-success">In Stock </span> and ready to ship!</p>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="price d-flex">
                                            <p>Price :</p>
                                            <p class="ms-auto">$<?php echo number_format($price, 2); ?></p>
                                        </div>
                                        <!-- Quantity Section -->
                                        <div class="d-flex">
                                            <span>Quantity</span>
                                            <div class="quantity-wrapper d-flex align-items-center mb-2 ms-auto">
                                                <input type="number" class="form-control mx-1 qty-input" value="<?php echo $quantity; ?>"
                                                    min="1" style="width: 40px;height: 31px;" data-id="<?php echo $product_id; ?>" />
                                            </div>
                                        </div>

                                        <div class="subtotal pt-1 d-flex">
                                            <p>Subtotal:</p>
                                            <p class="product-subtotal ms-auto" data-id="<?php echo $product_id; ?>">
                                                $<?php echo number_format($subtotal, 2); ?></p>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="cart-msg">Your cart is empty! Continue to Shopping <a href="products.php" class="btn btn-primary"><i
                                    class="fa fa-shopping-bag"></i></a></p>
                    <?php endif; ?>

                </div>
                <div class="col-md-4">
                    <h3 class="voucher-code">VOUCHER CODE</h3>
                    <div class="card p-3">
                        <form action="" style="display: flex;">
                            <input type="text" class="form-control" placeholder="Apply Code Here" />
                            <a href="" class="btn btn-secondary">Apply</a>
                        </form>
                    </div>

                    <?php if (!$cartEmpty): ?>
                        <h3 class="mt-4">ORDER SUMMARY</h3>
                        <div class="card p-3">
                            <div class="row">
                                <div class="col-md-12 d-flex cart-total">
                                    <p><b class="text-dark">Cart Total:</b></p>
                                    <p id="cart-total-amount" class="ms-auto">$<?php echo number_format($total, 2); ?></p>
                                </div>
                                <div class="col-md-12 d-flex shipping">
                                    <p><b class="text-dark">Shipping:</b></p>
                                    <p class="ms-auto">$2.00</p>
                                </div>
                                <div class="col-md-12 d-flex tax border-bottom">
                                    <p><b class="text-dark">Tax:</b></p>
                                    <p class="ms-auto">$1.00</p>
                                </div>
                                <div class="col-md-12 d-flex shipping">
                                    <p><b class="text-dark">Subtotal:</b></p>
                                    <p id="cart-subtotal" class="ms-auto">$<?php echo number_format($total + 3, 2); ?></p>
                                </div>

                                <div class="checkout text-center">
                                    <!-- Changed to button -->
                                    <button id="proceedToCheckout" class="btn btn-secondary float-mid" style="width: 100%;">
                                        PROCEED TO CHECKOUT
                                    </button>
                                </div>
                            </div>
                        </div>
                </div>
            <?php endif; ?>
            </div>
        </div>
    </div>
    </div>
    <!--------------- CHECKOUT SECTION END--------------->


    <!--------------------- FOOTER --------------------->

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4 text-md-start text-center">
                    <p>© 2023 Shope. All rights reserved.</p>
                </div>
                <div class="col-md-4 text-center">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
                <div class="col-md-4 text-md-end text-center">
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms & Conditions</a>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        crossorigin="anonymous"></script>

    <script>
        // On clicking Proceed to Checkout button
        document.getElementById('proceedToCheckout').addEventListener('click', function() {
            const products = [];
            <?php foreach ($cartItems as $product_id => $qty):
                if (!isset($products[$product_id])) continue;
                $product = $products[$product_id];
                $name = htmlspecialchars($product['clothname'], ENT_QUOTES);
                $quantity = (int)$qty;
                $price = (int)$product['price'];
            ?>
                products.push({
                    name: "<?php echo $name; ?>",
                    quantity: <?php echo $quantity; ?>,
                    price: <?php echo $price; ?>
                });
            <?php endforeach; ?>

            let params = new URLSearchParams();
            products.forEach((prod, idx) => {
                params.append(`product${idx + 1}_name`, prod.name);
                params.append(`product${idx + 1}_quantity`, prod.quantity);
                params.append(`product${idx + 1}_price`, prod.price);
            });

            window.location.href = 'confirmation.php?' + params.toString();
        });
    </script>
</body>

</html>