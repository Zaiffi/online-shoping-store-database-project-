<?php

include('../backend/connection.php');


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/style.css">
    <title>Shope. | Products</title>
</head>

<body>
    <!------------- NAV BAR -------------->

    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container">
            <a class="navbar-brand pt-3 pb-3" href="index.html">
                Shope.
            </a>
            <button class="navbar-toggler " type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <i class="fas fa-outdent"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link " href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="products.php">Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="blog.php">Blog</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="cart.php">
                            <i class="far fa-shopping-bag"></i>
                        </a>
                    </li>

                </ul>

            </div>
        </div>
    </nav>
    <!------------- NAV BAR END-------------->

    <!----------------- PRODUCT HERO SECTION -------------->
    <section class="product-hero">
        <div class="container pt-5">
            <h2>#stayhome</h2>
            <p>Save more with coupons & up to 70% off!</p>
        </div>
    </section>
    <!----------------- PRODUCT HERO SECTION END -------------->


    <!----------------- PRODUCT SECTION -------------->
    <div class="product">
        <div class="container">
            <div class="row row2">
                <?php
                $query = "SELECT * FROM indexproducts ORDER BY RAND() LIMIT 16";
                $res = mysqli_query($connection, $query);
                if (mysqli_num_rows($res) > 0) {
                    while ($row = mysqli_fetch_assoc($res)) {
                ?>
                        <div class="col-md-3">
                            <div class="card pro">
                                <a href="productdetail.php?id=<?php echo $row['id']; ?>" style="text-decoration: none; color: inherit;">
                                    <img src="assets/img/products/<?php echo ($row['image']); ?>" alt="">
                                    <div class="des">
                                        <span>
                                            <?php echo ($row['brandname']); ?>
                                        </span>
                                        <h5>
                                            <?php echo ($row['clothname']); ?>
                                        </h5>
                                        <div class="star">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <h4>
                                            $<?php echo ($row['price']); ?>
                                        </h4>
                                    </div>
                                    <a href="#" class="cart-btn" data-id="<?php echo $row['id']; ?>">
                                        <i class="fal fa-shopping-cart cart"></i>
                                    </a>
                            </div>
                        </div>
                <?php
                    }
                } else {
                    echo "<p>No products found.</p>";
                }
                ?>


            </div>
        </div>
    </div>

    </div>
    </div>

    <!----------------- NEWS LETTER SECTION -------------->
    <section class="news-letter mt-4">
        <div class="container">
            <div class="row pt-4 pb-2">
                <div class="col-md-6">
                    <div class="newstext">
                        <h4>Sign Up For Newsletter</h4>
                        <p>Get E-mail update about our latest shop and <span>special offers.</span></p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form">
                        <input type="text" placeholder="Your email address">
                        <button class="normal">Sign Up</button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!----------------- NEWS LETTER SECTION END-------------->

    <!--------------------- FOOTER SECTION ----------------->
    <footer class="mt-5">
        <div class="container">
            <div class="row pt-3 pb-3">
                <div class="col-md-4 first-col">
                    <div class="logo-div">
                        <a class="navbar-brand" href="index.html">
                            Shope.
                        </a>
                    </div>
                    <div class="contact">
                        <h4>Contact</h4>
                        <p><strong>Address:</strong> 562 Wellington Road,Street 32, San Feancisco</p>
                        <p><strong>Phone:</strong> +01 2222 365 /(+91) 01 2345 6789</p>
                        <p><strong>Hours:</strong> 10:00 - 18:00, Mon - Sat</p>
                    </div>
                    <div class="social-media">
                        <h4>Follow us</h4>
                        <div class="icon">
                            <i class="fab fa-facebook-f"></i>
                            <i class="fab fa-twitter"></i>
                            <i class="fab fa-instagram"></i>
                            <i class="fab fa-pinterest-p"></i>
                            <i class="fab fa-youtube"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 second-col">
                    <div class="row">
                        <div class="col-md-3">
                            <h4 class="pt-3">About</h4>
                            <ul>
                                <li><a href="#">About us</a></li>
                                <li><a href="#">Delivery information</a></li>
                                <li> <a href="#">Privacy Policy</a></li>
                                <li><a href="#">Term & Conditions</a></li>
                                <li><a href="#">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 pt-3">
                            <h4>My Account</h4>
                            <ul>
                                <li><a href="#">Sign In</a></li>
                                <li> <a href="#">View Cart</a></li>
                                <li> <a href="#">My Wishlist</a></li>
                                <li><a href="#">Track My Order</a></li>
                                <li> <a href="#">Help</a></li>
                            </ul>
                        </div>
                        <div class="col-md-6 pt-3">
                            <div class="col install">
                                <h4>Install App</h4>
                                <p>From App Store ad Google Play</p>
                                <div class="row">
                                    <div class="col-md-6">
                                        <img src="assets/img/pay/app.jpg" alt="">

                                    </div>
                                    <div class="col-md-6">
                                        <img src="assets/img/pay/play.jpg" alt="">
                                    </div>
                                </div>
                                <p>Secured Payment Getaways</p>
                                <img src="assets/img/pay/pay.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--------------------- FOOTER SECTION END----------------->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
        crossorigin="anonymous"></script>

    <script src="assets/js/script.js"></script>
    <script src="assets/js/cart.js"></script>
</body>

</html>