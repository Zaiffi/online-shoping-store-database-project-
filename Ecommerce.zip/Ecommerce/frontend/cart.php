<?php
session_start();
include('../backend/connection.php');
$cartItems = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$products = [];

if (!empty($cartItems)) {
    $ids = implode(',', array_keys($cartItems));
    $result = $connection->query("SELECT * FROM indexproducts WHERE id IN ($ids)");

    while ($row = $result->fetch_assoc()) {
        $products[$row['id']] = $row;
    }
}

$cartEmpty = empty($cartItems);

// Calculate total (product prices only)
$total = 0;
if (!$cartEmpty) {
    foreach ($cartItems as $product_id => $qty) {
        if (!isset($products[$product_id])) continue;
        $price = (int)$products[$product_id]['price'];
        $total += $price * (int)$qty;
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://unpkg.com/flickity@2/dist/flickity.min.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <title>Shope. | Cart</title>
</head>

<body>
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container">
            <a class="navbar-brand pt-3 pb-3" href="index.html">Shope.</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fas fa-outdent"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="products.php">Products</a></li>
                    <li class="nav-item"><a class="nav-link" href="blog.php">Blog</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                    <li class="nav-item"><a class="nav-link active" href="cart.php"><i class="far fa-shopping-bag"></i></a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- NAVBAR END -->

    <div class="carting" style="margin-top: 120px;">
        <div class="container">
            <div class="row left-row">
                <div class="col-md-8 mb-3">
                    <h3>MY CART</h3>

                    <?php if (!$cartEmpty): ?>
                        <?php
                        foreach ($cartItems as $product_id => $qty):
                            if (!isset($products[$product_id])) {
                                echo "<p>Product ID $product_id not found</p>";
                                continue;
                            }

                            $product = $products[$product_id];

                            $quantity = (int)$qty;
                            $price = (int)$product['price'];
                            $subtotal = $price * $quantity;
                        ?>
                            <div class="card mt-2">
                                <div class="row left-sub-row p-3">
                                    <div class="col-md-3 pic">
                                        <img src="../backend/admindashboard/index/Uploadimage/<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['clothname']); ?>" class="img-fluid" />
                                    </div>
                                    <div class="col-md-5 title">
                                        <h5><?php echo htmlspecialchars($product['clothname']); ?></h5>
                                        <p><b>Brand:</b> <?php echo htmlspecialchars($product['brandname']); ?></p>
                                        <p><span class="text-success">In Stock </span> and ready to ship!</p>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="price">
                                            <p>Price :</p>
                                            <p>$<?php echo number_format($price, 2); ?></p>
                                        </div>
                                        <!-- Quantity Section -->
                                        <div class="d-flex">
                                            <span>Quantity</span>
                                            <div class="quantity-wrapper d-flex align-items-center mb-2 ms-auto">
                                                <button class="btn btn-sm btn-outline-secondary qty-btn" data-action="decrease" data-id="<?php echo $product_id; ?>">−</button>
                                                <input type="number" class="form-control mx-1 qty-input" data-id="<?php echo $product_id; ?>" value="<?php echo $quantity; ?>" min="1" style="width: 40px;height: 30px;" />
                                                <button class="btn btn-sm btn-outline-secondary qty-btn" data-action="increase" data-id="<?php echo $product_id; ?>">+</button>
                                            </div>
                                        </div>

                                        <div class="subtotal pt-1">
                                            <p>Subtotal:</p>
                                            <p class="product-subtotal" data-id="<?php echo $product_id; ?>">$<?php echo number_format($subtotal, 2); ?></p>
                                        </div>
                                        <div class="cancle-order">
                                            <p>Cancel Order:</p>
                                            <a href="../backend/removecart.php?id=<?php echo $product_id; ?>"
                                                class="btn btn-danger d-flex align-items-center justify-content-center mt-2"
                                                style="height: 30px; width: 30px; border-radius: 5px;">
                                                <i class="fa fa-trash"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>

                    <?php else: ?>
                        <p class="cart-msg">Your cart is empty! Continue to Shopping <a href="products.php" class="btn btn-primary"><i class="fa fa-shopping-bag"></i></a></p>
                    <?php endif; ?>
                </div>

                <?php if (!$cartEmpty): ?>
                    <div class="col-md-4">
                        <h3>ORDER SUMMARY</h3>
                        <div class="card p-3">
                            <div class="row">
                                <div class="col-md-12 d-flex cart-total">
                                    <p><b class="text-dark">Cart Total:</b></p>
                                    <p id="cart-total-amount">$<?php echo number_format($total, 2); ?></p>
                                </div>
                                <div class="col-md-12 d-flex shipping">
                                    <p><b class="text-dark">Shipping:</b></p>
                                    <p>$2.00</p>
                                </div>
                                <div class="col-md-12 d-flex tax border-bottom">
                                    <p><b class="text-dark">Tax:</b></p>
                                    <p>$1.00</p>
                                </div>
                                <div class="col-md-12 d-flex shipping">
                                    <p><b class="text-dark">Subtotal:</b></p>
                                    <p id="cart-subtotal">$<?php echo number_format($total + 3, 2); ?></p>
                                </div>

                                <div class="checkout text-center">
                                    <a href="checkout.php" class="btn btn-secondary float-mid" style="width: 100%;">
                                        PROCEED TO CHECKOUT
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>

    <footer class="mt-5">
        <div class="container">
            <div class="row pt-3 pb-3">
                <div class="col-md-4 first-col">
                    <div class="logo-div">
                        <a class="navbar-brand" href="index.html">
                            Shope.
                        </a>
                    </div>
                    <div class="contact">
                        <h4>Contact</h4>
                        <p><strong>Address:</strong> 562 Wellington Road,Street 32, San Feancisco</p>
                        <p><strong>Phone:</strong> +01 2222 365 /(+91) 01 2345 6789</p>
                        <p><strong>Hours:</strong> 10:00 - 18:00, Mon - Sat</p>
                    </div>
                    <div class="social-media">
                        <h4>Follow us</h4>
                        <div class="icon">
                            <i class="fab fa-facebook-f"></i>
                            <i class="fab fa-twitter"></i>
                            <i class="fab fa-instagram"></i>
                            <i class="fab fa-pinterest-p"></i>
                            <i class="fab fa-youtube"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 second-col">
                    <div class="row">
                        <div class="col-md-3">
                            <h4 class="pt-3">About</h4>
                            <ul>
                                <li><a href="#">About us</a></li>
                                <li><a href="#">Delivery information</a></li>
                                <li> <a href="#">Privacy Policy</a></li>
                                <li><a href="#">Term & Conditions</a></li>
                                <li><a href="#">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 pt-3">
                            <h4>My Account</h4>
                            <ul>
                                <li><a href="#">Sign In</a></li>
                                <li> <a href="#">View Cart</a></li>
                                <li> <a href="#">My Wishlist</a></li>
                                <li><a href="#">Track My Order</a></li>
                                <li> <a href="#">Help</a></li>
                            </ul>
                        </div>
                        <div class="col-md-6 pt-3">
                            <div class="col install">
                                <h4>Install App</h4>
                                <p>From App Store ad Google Play</p>
                                <div class="row">
                                    <div class="col-md-6">
                                        <img src="assets/img/pay/app.jpg" alt="">

                                    </div>
                                    <div class="col-md-6">
                                        <img src="assets/img/pay/play.jpg" alt="">
                                    </div>
                                </div>
                                <p>Secured Payment Getaways</p>
                                <img src="assets/img/pay/pay.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/flickity@2/dist/flickity.pkgd.min.js"></script>
    <script src="assets/js/script.js"></script>
    <script src="assets/js/cart.js"></script>
    <script>
        function updateCartDisplay(data) {
            // Update product subtotal
            const productSubtotal = document.querySelector(`.product-subtotal[data-id="${data.product_id}"]`);
            if (productSubtotal && data.subtotal !== undefined) {
                productSubtotal.textContent = `$${data.subtotal.toFixed(2)}`;
            }

            // Update cart total and final subtotal (including shipping + tax)
            const cartTotalElem = document.getElementById('cart-total-amount');
            const finalSubtotalElem = document.getElementById('cart-subtotal');

            if (cartTotalElem && data.cartTotal !== undefined) {
                cartTotalElem.textContent = `$${(data.cartTotal - 3).toFixed(2)}`; // remove shipping+tax for cart total
            }
            if (finalSubtotalElem && data.cartTotal !== undefined) {
                finalSubtotalElem.textContent = `$${data.cartTotal.toFixed(2)}`; // include shipping+tax
            }
        }

        function updateQuantity(productId, quantity) {
            fetch('../backend/cartquantity.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `product_id=${productId}&quantity=${quantity}`,
                })
                .then(res => res.json())
                .then(data => {
                    if (data && data.success) {
                        updateCartDisplay(data);
                    } else {
                        console.error('Update failed', data);
                    }
                })
                .catch(err => console.error('Error:', err));
        }

        // Increase/decrease buttons
        document.querySelectorAll('.qty-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const productId = btn.dataset.id;
                const action = btn.dataset.action;
                const input = document.querySelector(`.qty-input[data-id="${productId}"]`);
                let quantity = parseInt(input.value);

                if (action === 'increase') quantity++;
                else if (action === 'decrease' && quantity > 1) quantity--;

                input.value = quantity;
                updateQuantity(productId, quantity);
            });
        });

        // Manual quantity input change
        document.querySelectorAll('.qty-input').forEach(input => {
            input.addEventListener('change', () => {
                const productId = input.dataset.id;
                let quantity = parseInt(input.value);
                if (isNaN(quantity) || quantity < 1) quantity = 1;
                input.value = quantity;
                updateQuantity(productId, quantity);
            });
        });

        // On page load sync quantities with backend
        window.addEventListener('load', () => {
            document.querySelectorAll('.qty-input').forEach(input => {
                const productId = input.dataset.id;
                const quantity = parseInt(input.value);
                updateQuantity(productId, quantity);
            });
        });
    </script>
</body>

</html>