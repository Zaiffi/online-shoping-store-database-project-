<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/style.css">
    <title>Shop</title>
</head>

<body>

    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container">
            <a class="navbar-brand pt-3 pb-3" href="index.html">
                Shope.
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <i class="fas fa-outdent"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link " href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="products.php">Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="blog.php">Blog</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="contact.php">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="cart.php">
                            <i class="far fa-shopping-bag"></i>
                        </a>
                    </li>
                </ul>

            </div>
        </div>
    </nav>

    <section id="page-header" class="about-header pt-5">
        <h2 class="pt-5">#let's_talk</h2>
        <p>LEAVE A MESSAGE, We Love to here from you!</p>
    </section>

    <section id="contact-details" class="section-p1">
        <div class="details">
            <span> GET IN TOUCH</span>
            <h2>Visit one of our agency location or contact us today</h2>
            <h3>Head Office</h3>
            <div>
                <li>
                    <i class="fal fa-map"></i>
                    <p>56 Glassford street Glasgow G1 1UL New York</p>
                </li>
                <li>
                    <i class="far fa-envelope"></i>
                    <p>contact@example.com</p>
                </li>
                <li>
                    <i class="fas fa-phone-alt"></i>
                    <p>contact@example.com</p>
                </li>
                <li>
                    <i class="far fa-clock"></i>
                    <p>Monday To Saturday: 9:00am to 16:00pm</p>
                </li>
            </div>
        </div>
        <div class="map">
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d55543.29749013708!2d71.58723485623732!3d29.532209228804444!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x393b9ee4e335c893%3A0x3cfb6dc1093330a9!2sLodhr%C4%81n%2C%20Lodhran%2C%20Punjab%2C%20Pakistan!5e0!3m2!1sen!2s!4v1725749023034!5m2!1sen!2s"
                width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </section>

    <section id="form-details">
        <form action="">
            <span>LEAVE A MESSAGE</span>
            <h2>We love to hear from you</h2>
            <input type="text" placeholder="Your Name">
            <input type="text" placeholder="E-mail">
            <input type="text" placeholder="Subject">
            <textarea name="" id="" cols="30" rows="10" placeholder="Your Message"></textarea>
            <button class="normal">Submit</button>
        </form>
        <div class="people">
            <div>
                <img src="assets/img/people/1.png" alt="">
                <p><span>John Doe</span> Senior Marketing Manager <br>Phone: +000 123 000 77 88 <br>Email:
                    contact@example.com</p>
            </div>
            <div>
                <img src="assets/img/people/2.png" alt="">
                <p><span>William Smith</span> Senior Marketing Manager <br>Phone: +000 123 000 77 88 <br>Email:
                    contact@example.com</p>
            </div>
            <div>
                <img src="assets/img/people/3.png" alt="">
                <p><span>Emma Stone</span> Senior Marketing Manager <br>Phone: +000 123 000 77 88 <br>Email:
                    contact@example.com</p>
            </div>
        </div>
    </section>

    <section id="news-letter" class="section-p1 section-m1">
        <div class="newstext">
            <h4>Sign Up For Newsletter</h4>
            <p>Get E-mail update about our latest shop and <span>special offers.</span></p>
        </div>
        <div class="form">
            <input type="text" placeholder="Your email address">
            <button class="normal">Sign Up</button>
        </div>
    </section>

    <footer class="mt-5">
        <div class="container">
            <div class="row pt-3 pb-3">
                <div class="col-md-4 first-col">
                    <div class="logo-div">
                        <a class="navbar-brand" href="index.html">
                            Shope.
                        </a>
                    </div>
                    <div class="contact">
                        <h4>Contact</h4>
                        <p><strong>Address:</strong> 562 Wellington Road,Street 32, San Feancisco</p>
                        <p><strong>Phone:</strong> +01 2222 365 /(+91) 01 2345 6789</p>
                        <p><strong>Hours:</strong> 10:00 - 18:00, Mon - Sat</p>
                    </div>
                    <div class="social-media">
                        <h4>Follow us</h4>
                        <div class="icon">
                            <i class="fab fa-facebook-f"></i>
                            <i class="fab fa-twitter"></i>
                            <i class="fab fa-instagram"></i>
                            <i class="fab fa-pinterest-p"></i>
                            <i class="fab fa-youtube"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 second-col">
                    <div class="row">
                        <div class="col-md-3">
                            <h4 class="pt-3">About</h4>
                            <ul>
                                <li><a href="#">About us</a></li>
                                <li><a href="#">Delivery information</a></li>
                                <li> <a href="#">Privacy Policy</a></li>
                                <li><a href="#">Term & Conditions</a></li>
                                <li><a href="#">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 pt-3">
                            <h4>My Account</h4>
                            <ul>
                                <li><a href="#">Sign In</a></li>
                                <li> <a href="#">View Cart</a></li>
                                <li> <a href="#">My Wishlist</a></li>
                                <li><a href="#">Track My Order</a></li>
                                <li> <a href="#">Help</a></li>
                            </ul>
                        </div>
                        <div class="col-md-6 pt-3">
                            <div class="col install">
                                <h4>Install App</h4>
                                <p>From App Store ad Google Play</p>
                                <div class="row">
                                    <div class="col-md-6">
                                        <img src="assets/img/pay/app.jpg" alt="">

                                    </div>
                                    <div class="col-md-6">
                                        <img src="assets/img/pay/play.jpg" alt="">
                                    </div>
                                </div>
                                <p>Secured Payment Getaways</p>
                                <img src="assets/img/pay/pay.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script src="assets/js/script.js"></script>
    <script src="assets/js/cart.js"></script>
</body>

</html>