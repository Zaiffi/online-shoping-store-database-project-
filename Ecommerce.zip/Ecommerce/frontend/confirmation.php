<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            background: linear-gradient(to right, #e0f7fa, #80deea);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        .message {
            font-size: 32px;
            color: #004d40;
            font-weight: bold;
            margin-bottom: 30px;
        }

        .btn {
            padding: 12px 24px;
            font-size: 16px;
            background-color: #00796b;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: background 0.3s;
            text-decoration: none;
        }

        .btn:hover {
            background-color: #004d40;
        }
    </style>
</head>

<body>
    <div class="message">Your order is shipped soon!</div>
    <a href="index.php" class="btn">Continue Shopping</a>
</body>

</html>