document.addEventListener('DOMContentLoaded', () => {
    const cartButtons = document.querySelectorAll('.cart-btn');

    cartButtons.forEach(btn => {
        btn.addEventListener('click', function (e) {
            e.preventDefault();

            const productId = this.getAttribute('data-id');

            fetch('../backend/cart.php?id=' + productId)
                .then(response => response.text())
                .then(data => {
                    showPopup('Item added to cart successfully!');
                });
        });
    });

    function showPopup(message) {
        let popup = document.createElement('div');
        popup.className = 'cart-popup';
        popup.textContent = message;
        document.body.appendChild(popup);

        setTimeout(() => {
            popup.remove();
        }, 5000);
    }
});
