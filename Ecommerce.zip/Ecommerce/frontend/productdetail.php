<?php

include('../backend/connection.php');


// Check if 'id' parameter is set in URL
if (isset($_GET['id'])) {
    $product_id = intval($_GET['id']); // id get karo aur integer mein convert karo for safety

    // Prepare and execute query to fetch product by id
    $stmt = $connection->prepare("SELECT * FROM indexproducts WHERE id =?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Agar product mil gaya to fetch karo, warna error show karo
    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();
    } else {
        echo "Product not found.";
        exit;
    }
} else {
    echo "No product ID specified.";
    exit;
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <title>Product Detail - <?php echo htmlspecialchars($product['clothname']); ?></title>
</head>

<body>

    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container">
            <a class="navbar-brand pt-3 pb-3" href="index.php">Shope.</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <i class="fas fa-outdent"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="products.php">Products</a></li>
                    <li class="nav-item"><a class="nav-link" href="blog.php">Blog</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                    <li class="nav-item">
                        <a class="nav-link" href="cart.php">
                            <i class="far fa-shopping-bag"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Product Detail Section -->
    <section id="prodetails" class="section-p1 mt-5 pt-5">
        <div class="container d-flex flex-wrap gap-4">

            <div class="single-pro-image flex-grow-1" style="max-width: 500px;">
                <img src="assets/img/products/<?php echo htmlspecialchars($product['image']); ?>" width="100%" id="MainImg"
                    alt="<?php echo htmlspecialchars($product['clothname']); ?>" />
                <!-- Small images can be dynamic too, if you have more images -->
                <div class="small-img-group d-flex justify-content-between mt-3">
                    <div class="small-img-col" style="width: 23%;">
                        <img src="assets/img/products/<?php echo htmlspecialchars($product['image']); ?>" class="small-img"
                            alt="<?php echo htmlspecialchars($product['clothname']); ?>" />
                    </div>

                </div>
            </div>

            <div class="single-pro-details flex-grow-1" style="max-width: 600px;">
                <h6>Home / <?php echo htmlspecialchars($product['brandname']); ?></h6>
                <h4><?php echo htmlspecialchars($product['clothname']); ?></h4>
                <h2>$<?php echo number_format($product['price'], 2); ?></h2>
                <p>Only Available in Medium Size</p>
                <form method="post" action="../backend/cart.php" class="mb-3">
                    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>" />
                    <a href="#" class="cart-btn btn btn-primary" data-id="<?php echo $product['id']; ?>">
                        <i class="fal fa-shopping-cart cart"></i> Add To Cart
                    </a>
                </form>


                <h4>Product Details</h4>
                <span>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Cum natus voluptate ullam laborum eos vitae sunt amet laboriosam quasi id, quisquam fuga ad enim. Dolorum id ratione architecto porro sapiente.</span>
            </div>
        </div>
    </section>


    <section class="product">
        <div class="container">
            <div class="row row1">
                <div class="col-md-12 text-center pt-5">
                    <h1>Featured Products</h1>
                    <p>Summer Collection New Modern Design</p>
                </div>
            </div>
            <div class="row row2">
                <?php
                $query = "SELECT * FROM indexproducts ORDER BY RAND() LIMIT 4";
                $res = mysqli_query($connection, $query);
                if (mysqli_num_rows($res) > 0) {
                    while ($row = mysqli_fetch_assoc($res)) {
                ?>
                        <div class="col-md-3">
                            <div class="card pro">
                                <a href="productdetail.php?id=<?php echo $row['id']; ?>" style="text-decoration: none; color: inherit;">
                                    <img src="assets/img/products/<?php echo ($row['image']); ?>" alt="">
                                    <div class="des">
                                        <span><?php echo ($row['brandname']); ?></span>
                                        <h5><?php echo ($row['clothname']); ?></h5>
                                        <div class="star">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <h4>$<?php echo ($row['price']); ?></h4>
                                    </div>
                                    <a href="#" class="cart-btn" data-id="<?php echo $row['id']; ?>">
                                        <i class="fal fa-shopping-cart cart"></i>
                                    </a>
                            </div>
                        </div>
                <?php
                    }
                } else {
                    echo "<p>No products found.</p>";
                }
                ?>


            </div>

        </div>
    </section>

    <section id="news-letter" class="section-p1 section-m1">
        <div class="newstext">
            <h4>Sign Up For Newsletter</h4>
            <p>Get E-mail update about our latest shop and <span>special offers.</span></p>
        </div>
        <div class="form">
            <input type="text" placeholder="Your email address" />
            <button class="normal">Sign Up</button>
        </div>
    </section>

    <footer class="mt-5">
        <div class="container">
            <div class="row pt-3 pb-3">
                <div class="col-md-4 first-col">
                    <div class="logo-div">
                        <a class="navbar-brand" href="index.html">
                            Shope.
                        </a>
                    </div>
                    <div class="contact">
                        <h4>Contact</h4>
                        <p><strong>Address:</strong> 562 Wellington Road,Street 32, San Feancisco</p>
                        <p><strong>Phone:</strong> +01 2222 365 /(+91) 01 2345 6789</p>
                        <p><strong>Hours:</strong> 10:00 - 18:00, Mon - Sat</p>
                    </div>
                    <div class="social-media">
                        <h4>Follow us</h4>
                        <div class="icon">
                            <i class="fab fa-facebook-f"></i>
                            <i class="fab fa-twitter"></i>
                            <i class="fab fa-instagram"></i>
                            <i class="fab fa-pinterest-p"></i>
                            <i class="fab fa-youtube"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 second-col">
                    <div class="row">
                        <div class="col-md-3">
                            <h4 class="pt-3">About</h4>
                            <ul>
                                <li><a href="#">About us</a></li>
                                <li><a href="#">Delivery information</a></li>
                                <li> <a href="#">Privacy Policy</a></li>
                                <li><a href="#">Term & Conditions</a></li>
                                <li><a href="#">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 pt-3">
                            <h4>My Account</h4>
                            <ul>
                                <li><a href="#">Sign In</a></li>
                                <li> <a href="#">View Cart</a></li>
                                <li> <a href="#">My Wishlist</a></li>
                                <li><a href="#">Track My Order</a></li>
                                <li> <a href="#">Help</a></li>
                            </ul>
                        </div>
                        <div class="col-md-6 pt-3">
                            <div class="col install">
                                <h4>Install App</h4>
                                <p>From App Store ad Google Play</p>
                                <div class="row">
                                    <div class="col-md-6">
                                        <img src="assets/img/pay/app.jpg" alt="">

                                    </div>
                                    <div class="col-md-6">
                                        <img src="assets/img/pay/play.jpg" alt="">
                                    </div>
                                </div>
                                <p>Secured Payment Getaways</p>
                                <img src="assets/img/pay/pay.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script src="assets/js/script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgY+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="assets/js/script.js"></script>
    <script src="assets/js/cart.js"></script>
</body>

</html>