<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/style.css">
    <title>Shop</title>
</head>

<body>

    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container">
            <a class="navbar-brand pt-3 pb-3" href="index.php">
                Shope.
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <i class="fas fa-outdent"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link " href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="products.php">Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="blog.php">Blog</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="cart.php">
                            <i class="far fa-shopping-bag"></i>
                        </a>
                    </li>

                </ul>

            </div>
        </div>
    </nav>

    <section id="page-header" class="about-header">
        <h2>#KnowUs</h2>
        <p>Lorem ispum dolor sit amet, consectetur</p>
    </section>

    <section id="about-head" class="section-p1">
        <img src="assets/img/about/a6.jpg" alt="">
        <div>
            <h2>Who We Are</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum iure ipsum et nemo architecto debitis
                nihil corrupti quia veritatis! Asperiores porro commodi tempore amet dolorum quisquam id distinctio sed
                beatae? Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse iusto dolor dolores nam aut
                corrupti doloremque illo, fugit, officiis, fugiat sequi. Culpa cum molestiae voluptatibus quo. Culpa
                reprehenderit beatae nam.</p>

            <abbr title="">Create stunning images with as much or as little control as you like thanks to a choice of
                Basic and Creative modes.</abbr>

            <br><br>

            <marquee bgcolor="#ccc" loop="-1" scrollamount="5" width="100%">Create stunning images with as much or as
                little control as you like thanks to a choice of
                Basic and Creative modes.</marquee>
        </div>
    </section>

    <section id="about-app" class="section-p1">
        <h1>Download our <a href="#">App</a></h1>
        <div class="video">
            <video autoplay muted src="assets/img/about/1.mp4"></video>
        </div>
    </section>

    <section id="features" class="section-p1">
        <div class="fe-box">
            <img src="assets/img/features/f1.png" alt="">
            <h6>Free Shipping</h6>
        </div>
        <div class="fe-box">
            <img src="assets/img/features/f2.png" alt="">
            <h6>Online Order</h6>
        </div>
        <div class="fe-box">
            <img src="assets/img/features/f3.png" alt="">
            <h6>Save Money</h6>
        </div>
        <div class="fe-box">
            <img src="assets/img/features/f4.png" alt="">
            <h6>Promotions</h6>
        </div>
        <div class="fe-box">
            <img src="assets/img/features/f5.png" alt="">
            <h6>Happy Sell</h6>
        </div>
        <div class="fe-box">
            <img src="assets/img/features/f6.png" alt="">
            <h6>F24/7 Support</h6>
        </div>
    </section>

    <section id="news-letter" class="section-p1 section-m1">
        <div class="newstext">
            <h4>Sign Up For Newsletter</h4>
            <p>Get E-mail update about our latest shop and <span>special offers.</span></p>
        </div>
        <div class="form">
            <input type="text" placeholder="Your email address">
            <button class="normal">Sign Up</button>
        </div>
    </section>

    <footer class="mt-5">
        <div class="container">
            <div class="row pt-3 pb-3">
                <div class="col-md-4 first-col">
                    <div class="logo-div">
                        <a class="navbar-brand" href="index.html">
                            Shope.
                        </a>
                    </div>
                    <div class="contact">
                        <h4>Contact</h4>
                        <p><strong>Address:</strong> 562 Wellington Road,Street 32, San Feancisco</p>
                        <p><strong>Phone:</strong> +01 2222 365 /(+91) 01 2345 6789</p>
                        <p><strong>Hours:</strong> 10:00 - 18:00, Mon - Sat</p>
                    </div>
                    <div class="social-media">
                        <h4>Follow us</h4>
                        <div class="icon">
                            <i class="fab fa-facebook-f"></i>
                            <i class="fab fa-twitter"></i>
                            <i class="fab fa-instagram"></i>
                            <i class="fab fa-pinterest-p"></i>
                            <i class="fab fa-youtube"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 second-col">
                    <div class="row">
                        <div class="col-md-3">
                            <h4 class="pt-3">About</h4>
                            <ul>
                                <li><a href="#">About us</a></li>
                                <li><a href="#">Delivery information</a></li>
                                <li> <a href="#">Privacy Policy</a></li>
                                <li><a href="#">Term & Conditions</a></li>
                                <li><a href="#">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 pt-3">
                            <h4>My Account</h4>
                            <ul>
                                <li><a href="#">Sign In</a></li>
                                <li> <a href="#">View Cart</a></li>
                                <li> <a href="#">My Wishlist</a></li>
                                <li><a href="#">Track My Order</a></li>
                                <li> <a href="#">Help</a></li>
                            </ul>
                        </div>
                        <div class="col-md-6 pt-3">
                            <div class="col install">
                                <h4>Install App</h4>
                                <p>From App Store ad Google Play</p>
                                <div class="row">
                                    <div class="col-md-6">
                                        <img src="assets/img/pay/app.jpg" alt="">

                                    </div>
                                    <div class="col-md-6">
                                        <img src="assets/img/pay/play.jpg" alt="">
                                    </div>
                                </div>
                                <p>Secured Payment Getaways</p>
                                <img src="assets/img/pay/pay.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script src="assets/js/script.js"></script>
    <script src="assets/js/cart.js"></script>
</body>

</html>